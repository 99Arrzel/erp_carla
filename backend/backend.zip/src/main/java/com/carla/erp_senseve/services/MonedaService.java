package com.carla.erp_senseve.services;

import com.carla.erp_senseve.models.MonedaModel;
import com.carla.erp_senseve.repositories.MonedaRepository;
import com.carla.erp_senseve.repositories.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MonedaService {
  @Autowired
  MonedaRepository monedaRepository;
  @Autowired
  UsuarioRepository usuarioRepository;
  public List<MonedaModel> monedasUsuario(String usuario) {
      Long idUsuario = usuarioRepository.findByUsuario(usuario).orElseThrow(
              () -> new RuntimeException("No existe usuario")
      ).getId();
      return monedaRepository.findByUsuarioId(idUsuario);
  }
  //Por id
    public MonedaModel monedaUsuario(Long id) {
        return monedaRepository.findById(id).orElseThrow(
                () -> new RuntimeException("No existe moneda")
        );
    }

}
