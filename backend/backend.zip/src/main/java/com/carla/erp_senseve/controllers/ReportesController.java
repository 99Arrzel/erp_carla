package com.carla.erp_senseve.controllers;

import com.carla.erp_senseve.models.ReporteComprobanteModel;
import com.carla.erp_senseve.services.ReporteComprobanteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping(value = "/api/reportes", consumes = MediaType.ALL_VALUE)
public class ReportesController {
    @Autowired
    ReporteComprobanteService reporteComprobanteService;
    @PostMapping(value = "/reporte_comprobante", consumes = MediaType.ALL_VALUE)
    public ResponseEntity<?> reporte_comprobante(
            @RequestHeader("Authorization") String authHeader,
            @RequestBody Map<String, String> data
            ) {
        try{
            System.out.println(data.get("id"));
            ReporteComprobanteModel reporteComprobanteModel = reporteComprobanteService.reporte_comprobante(data.get("id"));
            return ResponseEntity.ok().body(reporteComprobanteModel);
        }catch (Exception e){
            System.out.println(e.getMessage());
            return ResponseEntity.badRequest().body(e.getMessage().toString());
        }

    }
}
