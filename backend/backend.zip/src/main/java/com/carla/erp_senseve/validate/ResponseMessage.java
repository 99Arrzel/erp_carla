package com.carla.erp_senseve.validate;

public class ResponseMessage {
    private String msg;

    public ResponseMessage(String msg) {
        this.msg = msg;
    }

    public String getMsg() {
        return msg;
    }
   public void setMsg(String msg) {
        this.msg = msg;
    }
}