package com.carla.erp_senseve.services;

import com.carla.erp_senseve.models.ComprobanteModel;
import com.carla.erp_senseve.models.ReporteComprobanteModel;
import com.carla.erp_senseve.models.comprobante_detalles;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ReporteComprobanteService {
    @Autowired
    ComprobanteService comprobanteService;
    public ReporteComprobanteModel reporte_comprobante(String id_comprobante) {
        ReporteComprobanteModel reporteComprobanteModel = new ReporteComprobanteModel();
        //Fetch data from database using id_comprobante
        ComprobanteModel comprobanteModel = comprobanteService.obtener(id_comprobante);
        reporteComprobanteModel.setSerie(comprobanteModel.getSerie());
        reporteComprobanteModel.setEstado(comprobanteModel.getEstado());
        reporteComprobanteModel.setTipo(comprobanteModel.getTipo());
        reporteComprobanteModel.setFecha(comprobanteModel.getFecha());
        reporteComprobanteModel.setGlosa(comprobanteModel.getGlosa());
        reporteComprobanteModel.setMoneda(comprobanteModel.getMoneda().getNombre());
        reporteComprobanteModel.setUsuario(comprobanteModel.getUsuario().getNombre());
        reporteComprobanteModel.setEmpresa(comprobanteModel.getEmpresa().getNombre());
        comprobante_detalles detalles = new comprobante_detalles();
        comprobanteModel.getDetalles().forEach( detalle -> {
            detalles.setNumero(detalle.getNumero());
            detalles.setGlosa(detalle.getGlosa());
            detalles.setMonto_debe(detalle.getMonto_debe());
            detalles.setMonto_haber(detalle.getMonto_haber());
            detalles.setNombreCuenta(detalle.getCuenta().getNombre());
            detalles.setCodigoCuenta(detalle.getCuenta().getCodigo());
            reporteComprobanteModel.getComprobante_detalles().add(detalles);
                }
        );
        return reporteComprobanteModel;
    }

}
