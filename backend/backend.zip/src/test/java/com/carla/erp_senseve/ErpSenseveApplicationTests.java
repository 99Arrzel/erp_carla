package com.carla.erp_senseve;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ErpSenseveApplicationTests {

	@Test
	void contextLoads() {
	}

}
